
export type Verdict = 'safe' | 'unclear' | 'likely_scam' | 'high_risk';

type Flag = { pattern: RegExp; weight: number; why: string };

const FLAGS: Flag[] = [
  { pattern: /(urgent|immediate|final notice|verify now|act now)/i, weight: 10, why: 'Urgent pressure' },
  { pattern: /(gift ?card|crypto|bitcoin|wire transfer|payid)/i, weight: 15, why: 'Risky payment method' },
  { pattern: /(account (?:locked|suspended)|unpaid|toll|fine|invoice)/i, weight: 12, why: 'Account/payment pressure' },
  { pattern: /(remote access|anydesk|teamviewer|install app)/i, weight: 20, why: 'Remote‑access request' },
  { pattern: /(arrest|lawsuit|warrant|immigration|tax debt|ato|irs)/i, weight: 18, why: 'Threats / gov impersonation' },
  { pattern: /(click (?:here|link)|http:\/\/|bit\.ly|tinyurl|linktr\.|\.ru\b|\.xyz\b|\.[a-z]{2,}\/\S{0,15}\?)/i, weight: 10, why: 'Suspicious link' },
  { pattern: /(passcode|otp|verification code|password)/i, weight: 14, why: 'Asking for codes/passwords' },
  { pattern: /(bank|australia post|linkt|mygov|irs|ssa|centrelink|usps|ups|dhl)/i, weight: 8, why: 'Brand/gov keywords' },
  { pattern: /([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,})/i, weight: 5, why: 'Email present (check domain)' },
  { pattern: /(\+?\d{1,2}\s?)?(\(?\d{2,3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}/, weight: 5, why: 'Phone number present' },
];

export function scoreText(text: string) {
  let score = 0;
  const hits: string[] = [];
  for (const f of FLAGS) {
    if (f.pattern.test(text)) {
      score += f.weight;
      hits.push(f.why);
    }
  }
  score = Math.max(0, Math.min(100, score));
  let verdict: Verdict = 'safe';
  if (score >= 75) verdict = 'high_risk';
  else if (score >= 50) verdict = 'likely_scam';
  else if (score >= 25) verdict = 'unclear';
  return { score, verdict, hits: Array.from(new Set(hits)) };
}

export function actionsFor(region: 'AU' | 'US', verdict: Verdict): string[] {
  const AU: Record<Verdict, string[]> = {
    safe: ['Looks fine. Stay cautious.', 'Avoid sharing codes or passwords.'],
    unclear: [
      'Do not click links or reply yet.',
      'Contact the company using a phone number from its official website.'
    ],
    likely_scam: [
      'Don’t reply or click any links.',
      'Block the sender.',
      'Report SMS to your telco (Telstra 7226; Optus via My Optus app).',
      'Report at Scamwatch; use ReportCyber if money/ID at risk.'
    ],
    high_risk: [
      'Stop. Do not pay or share codes.',
      'Block and delete the message.',
      'Report now: Telstra 7226 / Optus ScamWise; Scamwatch; ReportCyber; call your bank.'
    ]
  };
  const US: Record<Verdict, string[]> = {
    safe: ['Looks fine. Stay cautious.'],
    unclear: ['Don’t click links yet.', 'Contact the company using a trusted number/website.'],
    likely_scam: [
      'Don’t reply or click links.',
      'Block the sender.',
      'Forward the text to 7726 (SPAM).',
      'Report at ReportFraud.ftc.gov; use IdentityTheft.gov if ID is at risk.'
    ],
    high_risk: [
      'Stop. Do not pay or share codes.',
      'Block and delete the message.',
      'Forward to 7726 (SPAM) and report at ReportFraud.ftc.gov; contact your bank.'
    ]
  };
  return (region === 'AU' ? AU : US)[verdict];
}

export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[\w.-]+(?:\/[\w./?%&=+#-]*)?/gi;
  return Array.from(new Set(text.match(urlRegex) || []));
}

export function labelForUrl(url: string): { label: 'safe' | 'suspicious' | 'danger'; why: string } {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    const tld = host.split('.').pop() || '';
    const isShortener = /(bit\.ly|t\.co|tinyurl\.com|goo\.gl|ow\.ly|rb\.gy|linktr\.ee)/.test(host);
    const isHttp = u.protocol === 'http:';
    const looksLikeBrand = /(auspost|linkt|mygov|irs|usps|ups|dhl|anz|cba|westpac|nab|bofa|chase|wellsfargo)/.test(host);
    const hasIp = /^\d+\.\d+\.\d+\.\d+$/.test(host);
    const oddTld = /(ru|tk|cn|xyz|top|click|rest|work|zip|kim|country|cc)$/.test(tld);
    if (hasIp || isHttp || oddTld) return { label: 'danger', why: 'Unusual host/TLD or not https' };
    if (isShortener) return { label: 'suspicious', why: 'URL shortener used' };
    if (!looksLikeBrand) return { label: 'suspicious', why: 'Domain doesn’t match claimed brand' };
    return { label: 'suspicious', why: 'Treat unknown links cautiously' };
  } catch {
    return { label: 'suspicious', why: 'Malformed URL' };
  }
}

export function redact(text: string): string {
  return text
    // emails
    .replace(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/gi, '[redacted-email]')
    // phone numbers
    .replace(/(\+?\d{1,2}\s?)?(\(?\d{2,3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}/g, '[redacted-phone]')
    // likely account numbers (8–16 digits)
    .replace(/\b\d{8,16}\b/g, '[redacted-number]');
}
