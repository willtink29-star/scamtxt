
'use client';
import React from 'react';
import { createWorker } from 'tesseract.js';
import { scoreText, actionsFor, extractUrls, labelForUrl, redact, Verdict } from './components/RiskScorer';

export default function Page() {
  const [region, setRegion] = React.useState<'AU'|'US'>('AU');
  const [elder, setElder] = React.useState(true);
  const [text, setText] = React.useState('');
  const [working, setWorking] = React.useState(false);
  const [ocrLog, setOcrLog] = React.useState<string>('');
  const [redacted, setRedacted] = React.useState<string>('');

  const result = React.useMemo(() => scoreText(text), [text]);
  const advice = React.useMemo(() => actionsFor(region, result.verdict as Verdict), [region, result.verdict]);
  const urls = React.useMemo(() => extractUrls(text), [text]);

  async function handleImage(file: File) {
    setWorking(true);
    setOcrLog('Loading OCR…');
    const worker = await createWorker('eng'); // For more languages, preload packs (see README)
    setOcrLog('Recognising text…');
    const { data } = await worker.recognize(file);
    await worker.terminate();
    setOcrLog('');
    setText((prev) => (prev ? prev + '\n' : '') + data.text.trim());
  }

  function handleRedact() {
    setRedacted(redact(text));
  }

  const barColor = result.score >= 75 ? '#ef4444' : result.score >= 50 ? '#f59e0b' : result.score >= 25 ? '#fde047' : '#10b981';
  const verdictClass = result.verdict === 'high_risk' ? 'badge high' : result.verdict === 'likely_scam' ? 'badge likely' : result.verdict === 'unclear' ? 'badge unclear' : 'badge safe';

  return (
    <div className="container" style={{ fontSize: elder ? 18 : 16 }}>
      <div className="card">
        <h1>ScamTXT — Quick Check</h1>
        <div className="row">
          <label className="inline">Region
            <select className="input" value={region} onChange={e => setRegion(e.target.value as 'AU'|'US')}>
              <option value="AU">Australia</option>
              <option value="US">United States</option>
            </select>
          </label>
          <label className="inline">
            <input type="checkbox" checked={elder} onChange={e => setElder(e.target.checked)} /> Elder Mode
          </label>
        </div>

        <div style={{ height: 12 }} />

        <label>Paste suspicious text or email</label>
        <textarea placeholder="Paste the message here…" value={text} onChange={e=>setText(e.target.value)} />

        <div className="row upload">
          <input type="file" accept="image/*" onChange={(e)=> e.target.files && handleImage(e.target.files[0])} />
          {working && <span className="small">{ocrLog}</span>}
        </div>

        <div style={{ height: 8 }} />
        <div className="section-title">Risk Meter</div>
        <div className="progress"><div style={{ width: `${result.score}%`, background: barColor }} /></div>
        <div className="row">
          <span className={verdictClass} style={{textTransform:'capitalize'}}>{result.verdict.replace('_',' ')}</span>
          <span className="small">Score: {result.score} / 100</span>
        </div>

        <hr />

        <div className="section-title">Why we think this</div>
        {result.hits.length === 0 ? <div className="small">No obvious red flags found. Stay cautious.</div> : (
          <ul className="list">
            {result.hits.map((h, i) => <li key={i}>{h}</li>)}
          </ul>
        )}

        <div className="section-title">Links in message</div>
        {urls.length === 0 ? <div className="small">None detected.</div> : (
          <ul className="list">
            {urls.map((u, i)=>{
              const {label, why} = labelForUrl(u);
              return <li key={i}><a href={u} target="_blank" rel="noreferrer">{u}</a> — <strong>{label}</strong> <span className="small">({why})</span></li>
            })}
          </ul>
        )}

        <div className="section-title">What to do now</div>
        <ul className="list">
          {advice.map((a,i)=><li key={i}>{a}</li>)}
        </ul>

        <div className="row">
          {region === 'AU' ? (
            <>
              <a className="btn ghost" href="sms:7226">SMS 7226 (Telstra)</a>
              <a className="btn ghost" href="https://www.scamwatch.gov.au/report-a-scam" target="_blank">Scamwatch</a>
              <a className="btn ghost" href="https://www.cyber.gov.au/report-and-recover/report" target="_blank">ReportCyber</a>
            </>
          ) : (
            <>
              <a className="btn ghost" href="sms:7726">SMS 7726 (SPAM)</a>
              <a className="btn ghost" href="https://reportfraud.ftc.gov/" target="_blank">ReportFraud.ftc.gov</a>
              <a className="btn ghost" href="https://www.identitytheft.gov/" target="_blank">IdentityTheft.gov</a>
            </>
          )}
        </div>

        <hr />
        <div className="section-title">Redact personal info</div>
        <div className="row">
          <button className="btn secondary" onClick={handleRedact}>Redact</button>
          {redacted && <button className="btn" onClick={()=>navigator.clipboard.writeText(redacted)}>Copy redacted</button>}
        </div>
        {redacted && (<>
          <div style={{height:8}} />
          <textarea value={redacted} readOnly />
        </>)}

        <footer>
          Advisory only; we can’t guarantee outcomes. Don’t send money, gift cards, or codes to unknown contacts. In emergencies or threats, contact local authorities.
        </footer>
      </div>
    </div>
  );
}
