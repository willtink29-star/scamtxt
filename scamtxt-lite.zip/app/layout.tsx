
import './globals.css';

export const metadata = {
  title: 'ScamTXT — Quick Check',
  description: 'Paste a suspicious message or upload a screenshot. AU + US ready, no server required.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
