
# ScamTXT Lite (AU + US)

A free, no‑backend web app for seniors to paste a suspicious text/email or add a screenshot and get:
- a **Risk Meter** (Safe / Unclear / Likely Scam / High Risk),
- simple **reasons**,
- and **what to do now** (country‑aware for AU/US).

## Why this repo?
You asked for something you can **publish without paying for Glide**. This runs on any free static host (Vercel free tier works great).

## Features
- Client‑side only (privacy by default; no server needed).
- Paste text or **upload image** (OCR via Tesseract.js in the browser).
- On‑device **heuristics** score (no API key needed).
- Country toggle: **Australia / United States**.
- One‑tap **reporting links**: 7226 (AU), 7726 (US), Scamwatch/ReportFraud, etc.
- Elder‑friendly UI (big text toggle, high contrast).

## Quick start
```bash
# 1) install
npm install

# 2) run locally
npm run dev

# 3) build for production
npm run build && npm start
```
Then deploy to Vercel (Import Git repo → framework: Next.js).

## Optional: Enable OCR language packs
Tesseract defaults to English. If you need more languages, load them in `/app/page.tsx` (comment included).

## Optional: Add an LLM later
If you want “best‑prompt” classification, add a serverless function that calls your LLM using the prompts in `/prompts/prompts.md`. This starter already works **without** it.

## License
MIT. Use at your own risk; advisory only.
